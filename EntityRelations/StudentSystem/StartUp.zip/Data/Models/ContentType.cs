﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        //enum – can be Application, Pdf or Zip)
        
        
        Application = 10,
        Pdf = 20,
        Zip = 30

    }
}
