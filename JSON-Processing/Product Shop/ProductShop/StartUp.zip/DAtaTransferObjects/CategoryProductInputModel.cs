﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DAtaTransferObjects
{
    public class CategoryProductInputModel
    {
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }
    
}
