﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DAtaTransferObjects
{
    public class CategoryInputModel
    {

        public string Name { get; set; }

    }
}
